package com.example.gan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
