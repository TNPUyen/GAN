import 'package:gan/controllers/navbar_controller.dart';

NavBarController navBarController = NavBarController.instance;